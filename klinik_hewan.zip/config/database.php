<?php
$conn = mysqli_connect("localhost", "root", "", "klinik_hewan");